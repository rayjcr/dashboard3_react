# Daily Detail Report 页面规格说明书

## 概述

Daily Detail Report 页面是用户从 Daily Summary 表格中点击日期链接后展示的详细报告页面。该页面展示指定日期的完整交易明细、费用信息和结算汇总。

---

## 用户故事

### US1: 日期详情查看

**作为**用户，**我希望**点击 Daily Summary 中的日期链接后，能够查看该日期的详细交易报告，**以便**了解当天的完整交易信息和费用明细。

**验收标准**：

1. 点击日期链接后跳转到详情页面
2. 页面显示选中日期的所有交易明细
3. 页面显示费用信息（Monthly Fee、Settlement Fee、Reserve、Itemized Fee、Misc Fee）
4. 页面显示 Payment Pending 和 Payment Settled 汇总
5. 提供返回按钮可以返回 Dashboard 页面

---

## 路由配置

| 路由      | 组件                    | 说明             |
| --------- | ----------------------- | ---------------- |
| `/detail` | `DailyDetailReportPage` | 日期详情报告页面 |

### URL 参数

| 参数名     | 类型    | 必填 | 说明                              |
| ---------- | ------- | ---- | --------------------------------- |
| merchantId | string  | 是   | 商户 ID                           |
| date       | string  | 是   | 日期，格式 `YYYY-MM-DD`           |
| isIsv      | boolean | 是   | 是否为 ISV 商户（`true`/`false`） |

**示例 URL**：

```
/detail?merchantId=634201701345000&date=2026-01-20&isIsv=false
```

---

## API 接口

### 获取日期详情报告

- **接口**：`POST /detail_daily_report`
- **请求参数**：

| 参数       | 类型    | 说明                |
| ---------- | ------- | ------------------- |
| merchantId | string  | 商户 ID             |
| date       | string  | 日期 (`YYYY-MM-DD`) |
| sessionId  | string  | 会话 ID             |
| isIsv      | boolean | 是否为 ISV 商户     |

- **响应数据结构**：见 `src/types/dashboard.ts` 中的 `DailyDetailReportResponse`

---

## 页面布局

### 整体结构

```
┌─────────────────────────────────────────────────────────────┐
│  [Back]                                                      │
├─────────────────────────────────────────────────────────────┤
│  📅 Monday, January 20, 2026                                │
│  Merchant Name · Store Name                    [PENDING] USD │
├─────────────────────────────────────────────────────────────┤
│  From              │  To              │  Status              │
│  Bank Name         │  Store Name      │  PENDING             │
│  Account Info      │                  │  Period Start: ...   │
│                    │                  │  Period End: ...     │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Transactions ─────────────────────────────────────────┐ │
│  │ 表格（始终显示表头，无数据时显示空状态）                  │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Disputes ─────────────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Monthly Fee ──────────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Settlement Fee ───────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Reserve ──────────────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Itemized Fee ─────────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Misc Fee ─────────────────────────────────────────────┐ │
│  │ 表格（有数据时显示）                                    │ │
│  └────────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  Net of the day: ┌──────────┐                              │
│                  │ $1,234.56│                              │
│                  └──────────┘                              │
├─────────────────────────────────────────────────────────────┤
│  ┌─ Tips ────────┐  ┌─ Payment Pending ──────────────────┐ │
│  │ Tip 1         │  │ 汇总表格                            │ │
│  │ Tip 2         │  └────────────────────────────────────┘ │
│  │ ...           │  ┌─ Payment Settled ──────────────────┐ │
│  └───────────────┘  │ 汇总表格                            │ │
│                     └────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## UI 组件规格

### 1. 页面头部

#### 返回按钮

- 图标：`ArrowLeftOutlined`
- 点击后返回上一页（`navigate(-1)`）

#### 日期标题区域

- **日期格式**：完整格式显示，如 `Monday, January 20, 2026`
- **图标**：`CalendarOutlined`，使用主题色
- **商户信息**：显示 `merchant_name · store_name`
- **状态标签**：`Tag` 组件，颜色根据状态变化
  - `PENDING`：橙色
  - `paid`：绿色
  - 其他：蓝色
- **货币**：显示当前货币代码

#### 分割线样式

- **凹凸效果**：
  ```css
  border-bottom: 1px solid rgba(0, 0, 0, 0.15);
  box-shadow: 0 1px 0 0 rgba(255, 255, 255, 0.9);
  ```

### 2. 基本信息卡片（From/To/Status）

三列布局，使用凹凸分割线分隔：

| 列     | 内容                               |
| ------ | ---------------------------------- |
| From   | 付款方信息（多行），**第一行加粗** |
| To     | 收款方店铺名称，**加粗显示**       |
| Status | 状态、交易周期开始/结束时间        |

#### 分割线样式

```css
/* 凹凸分割线 */
background: linear-gradient(
  to right,
  rgba(0, 0, 0, 0.06),
  rgba(255, 255, 255, 0.8)
);
```

### 3. 表格区域通用样式

#### Section 容器样式

```css
 {
  marginbottom: 16px;
  border: 1px solid #d9d9d9;
  borderradius: 6px;
  overflow: hidden;
}
```

#### Section 标题栏样式

```css
 {
  padding: 8px 12px;
  background: #e8e8e8;
  borderbottom: 1px solid #d9d9d9;
}
```

#### 标题文字样式

```css
 {
  fontsize: 18px;
  fontweight: 100;
  color: rgba(0, 0, 0, 0.85);
}
```

### 4. Transactions 表格

- **始终显示表头**：即使没有数据也显示表头
- **空状态**：显示 "No transaction data" 提示
- **分页**：有数据时显示分页控件
- **表格样式**：使用 `dashboard-table` class

#### 表头配置

| 列名                      | 字段映射                         | 说明         |
| ------------------------- | -------------------------------- | ------------ |
| Transaction ID            | `transaction_id`                 | 交易 ID      |
| Reference ID              | `reference`                      | 参考号       |
| Date/Time                 | `time_created`                   | 创建时间     |
| Transaction Type          | `transaction_type`               | 交易类型     |
| Payment Method            | `payment_method`                 | 支付方式     |
| Card Number               | `buyer_id`                       | 卡号         |
| Vendor Reference          | `method_trans_id`                | 供应商参考号 |
| Gross                     | `total`                          | 总额         |
| Discount                  | `merchant_discount`              | 折扣         |
| Authorization             | `merchant_fixed`                 | 授权费       |
| VAT                       | `vat_fee`                        | 增值税       |
| Net                       | `net`                            | 净额         |
| Tip                       | `tip`                            | 小费         |
| Login Code                | `login_code`                     | 登录码       |
| Settle time               | `time_settled`                   | 结算时间     |
| Store of Original Payment | `original_merchant_name_english` | 原始支付商户 |

### 5. 其他表格 Section

以下表格仅在有数据时显示：

- **Disputes**：争议记录
- **Monthly Fee**：月费
- **Settlement Fee**：结算费
- **Reserve**：保证金
- **Itemized Fee**：明细费用
- **Misc Fee**：杂费

### 6. Net of the day 区域

#### 样式

```css
/* 外框样式 */
 {
  display: inline-block;
  padding: 6px 16px;
  background: linear-gradient(135deg, #f6f8fc 0%, #eef2f7 100%);
  border: 1px solid #d9d9d9;
  borderradius: 6px;
  boxshadow: inset 0 1px 2px rgba(255, 255, 255, 0.8), 0 1px 3px rgba(0, 0, 0, 0.08);
}

/* 金额文字样式 */
 {
  fontsize: 16px;
  color: rgba(0, 0, 0, 0.85);
  fontweight: 600;
}
```

### 7. Tips 区域

#### 容器样式

- 宽度：占左侧 8/24 列
- 边框：`1px solid #d9d9d9`
- 圆角：`6px`

#### 标题样式

与其他 Section 一致：

```css
 {
  fontsize: 18px;
  fontweight: 100;
  color: rgba(0, 0, 0, 0.85);
}
```

#### 内容项样式

```css
 {
  padding: 8px 10px;
  fontsize: 12px;
  lineheight: 1.5;
  color: rgba(0, 0, 0, 0.65);
  borderradius: 4px;
  borderleft: 3px solid #bfbfbf; /* 灰色左边框 */
  background: transparent; /* 无背景色 */
}
```

### 8. Payment Pending / Payment Settled 区域

#### 容器样式

- 宽度：占右侧 16/24 列
- 上边框：`3px solid {primaryColor}`（主题紫色）
- 边框：`1px solid #d9d9d9`
- 圆角：`6px`

#### 标题样式

```css
 {
  fontsize: 20px;
  fontweight: 100;
  color: rgba(0, 0, 0, 0.85); /* 不使用彩色 */
}
```

#### 表格第一列

- **加粗显示**：使用 `<Text strong>` 包裹

#### 表格行内容

| 行标签                | 说明     | 显示条件                 |
| --------------------- | -------- | ------------------------ |
| Number of Transaction | 交易数量 | 始终显示                 |
| Sub Total             | 小计     | 始终显示                 |
| Tip                   | 小费     | 始终显示                 |
| Fee                   | 费用     | 始终显示                 |
| VAT                   | 增值税   | `showVAT` 为 true        |
| Reserve               | 保证金   | `hasReserve` 为 true     |
| Itemized Fee          | 明细费用 | `hasItemizedFee` 为 true |
| Misc Fee              | 杂费     | 有 `apexFee` 数据时      |
| Net                   | 净额     | 始终显示                 |

---

## 数据加载

### 加载策略

1. 页面初始化时，从 URL 参数获取 `merchantId`、`date`、`isIsv`
2. 调用 `/detail_daily_report` API 获取数据
3. 使用 `useRef` 防止重复加载
4. 加载完成后渲染页面内容

### 错误处理

- **参数缺失**：显示 "Missing required parameters" 错误
- **API 失败**：显示 "Failed to load daily detail report" 错误并允许返回
- **无数据**：显示 "No data available" 空状态

---

## 样式规范

### 颜色定义

| 用途             | 颜色值                                       |
| ---------------- | -------------------------------------------- |
| 主题色（紫色）   | `#7c3aed`（深色模式）/ `#1890ff`（浅色模式） |
| Section 标题背景 | `#e8e8e8`                                    |
| Section 边框     | `#d9d9d9`                                    |
| 标题文字         | `rgba(0, 0, 0, 0.85)`                        |
| Tips 左边框      | `#bfbfbf`                                    |
| Tips 文字        | `rgba(0, 0, 0, 0.65)`                        |

### 字体规范

| 元素                 | fontSize | fontWeight |
| -------------------- | -------- | ---------- |
| Section 标题         | 18px     | 100        |
| Payment Summary 标题 | 20px     | 100        |
| Net of the day 值    | 16px     | 600        |
| From/To 第一行值     | 13px     | 600        |
| Tips 内容            | 12px     | 400        |

---

## 文件位置

| 文件                                     | 说明                             |
| ---------------------------------------- | -------------------------------- |
| `src/pages/DailyDetailReportPage.tsx`    | 页面组件                         |
| `src/pages/DashboardPage.tsx`            | Dashboard 页面（返回时使用缓存） |
| `src/router/routes.tsx`                  | 路由配置                         |
| `src/services/api/summaryApi.ts`         | API 接口                         |
| `src/types/dashboard.ts`                 | 类型定义                         |
| `src/components/dashboard/dashboard.css` | 表格通用样式                     |

---

## 返回导航缓存策略

### 问题描述

当用户从 Detail 页面点击 Back 按钮返回 Dashboard 页面时，应该使用缓存的数据而不是重新加载。

### 解决方案

在 `DashboardPage.tsx` 中实现以下缓存逻辑：

1. **状态初始化**：组件挂载时检查 store 中是否已有数据

   ```typescript
   const [activeTab, setActiveTab] = useState<string>(() => {
     if (useDashboardStore.getState().dailySummary) {
       return 'daily';
     }
     return '';
   });
   const [dailyLoaded, setDailyLoaded] = useState<boolean>(() => {
     return !!useDashboardStore.getState().dailySummary;
   });
   ```

2. **加载标记初始化**：如果 store 中已有数据，设置 `initialLoadRef` 为当前节点的 key

   ```typescript
   const getInitialLoadKey = (): string | null => {
     const state = useDashboardStore.getState();
     if (state.dailySummary && selectedNode?.id && sessionId) {
       return `${selectedNode.id}-${sessionId}`;
     }
     return null;
   };
   const initialLoadRef = useRef<string | null>(getInitialLoadKey());
   ```

3. **数据加载判断**：如果 `initialLoadRef.current === nodeKey`，跳过重新加载

### 效果

- 从 Detail 页面返回时，如果 store 中已有 Daily Summary 数据，直接显示缓存数据
- 避免不必要的 API 请求
- 保持用户的分页状态和筛选条件

---

## 更新历史

| 日期       | 更新内容                                                            |
| ---------- | ------------------------------------------------------------------- |
| 2026-01-27 | 初始版本：创建 Daily Detail Report 页面规格说明                     |
| 2026-01-27 | 更新路由从 `/daily-detail` 修改为 `/detail`                         |
| 2026-01-27 | 更新 Section 标题样式：`fontSize: 18px`, `fontWeight: 100`          |
| 2026-01-27 | 更新 Payment Pending/Settled 标题：使用主题紫色上边框，标题文字黑色 |
| 2026-01-27 | 更新 Tips 左边框颜色从紫色改为灰色 (`#bfbfbf`)                      |
| 2026-01-27 | 更新头部分割线为凹凸效果                                            |
| 2026-01-27 | 更新 From/To 区域第一行值加粗                                       |
| 2026-01-27 | 更新 Net of the day 值使用外框包裹设计                              |
| 2026-01-27 | Transactions 表格始终显示表头，空数据时显示提示文字                 |
| 2026-01-27 | 添加返回导航缓存策略：从 Detail 页面返回时使用缓存数据              |
