# Feature Specification: Layout 组件

## 概述

Dashboard 主布局组件，采用经典管理后台布局模式：顶部导航栏 + 左侧可折叠菜单 + 内容区 + 底部。整体采用**简洁现代（类似 Ant Design Pro）的整体风格**风格，支持完整响应式设计。

---

## 用户故事

### US1: 顶部导航栏 (Header)

**作为** 已登录用户  
**我希望** 看到固定在顶部的导航栏，包含 Logo 和面包屑导航  
**以便于** 快速了解当前位置并导航到其他页面

**验收标准:**

- [ ] Header 固定在顶部，滚动时不消失 (`position: fixed` 或 `sticky`)
- [ ] 左侧显示 "Citcon" Logo/公司名称
- [ ] Logo 右侧显示面包屑导航 (Breadcrumb)，反映当前页面层级
- [ ] Header 高度约 64px
- [ ] 简洁现代（类似 Ant Design Pro）的整体风格

---

### US2: 响应式布局

**作为** 移动端用户  
**我希望** 在小屏幕设备上也能正常使用 Dashboard  
**以便于** 随时随地查看数据

**验收标准:**

- [ ] 桌面端 (≥1024px): 标准布局，Sidebar 始终可见
- [ ] 平板端 (768px - 1023px): Sidebar 默认折叠，可手动展开
- [ ] 移动端 (<768px):
  - Sidebar 变为抽屉模式 (Drawer)
  - Header 显示汉堡菜单图标 (☰)
  - 点击汉堡图标打开/关闭 Sidebar 抽屉
  - 抽屉有遮罩层，点击遮罩关闭抽屉

---

### US3: Footer

**作为** 已登录用户  
**我希望** 页面底部显示版权信息  
**以便于** 了解产品归属

**验收标准:**

- [ ] Footer 显示简单版权信息: `© 2026 Citcon. All rights reserved.`
- [ ] Footer 固定在内容区底部（内容不足时贴底，内容超出时随内容滚动）
- [ ] 简洁现代（类似 Ant Design Pro）的整体风格

---

## 布局结构

```
┌─────────────────────────────────────────────────────────────┐
│  Header (固定顶部, 64px)                                      │
│  ┌──────────┬──────────────────────────────────────────────┐│
│  │  Logo    │  Breadcrumb: Home > Merchants > Detail       ││
│  └──────────┴──────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────┤
│ ┌──────────┐ ┌─────────────────────────────────────────────┐│
│ │ Sidebar  │ │  Main Content Area                          ││
│ │ (256px)  │ │                                             ││
│ │          │ │  <Outlet />                                 ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ │          │ │                                             ││
│ └──────────┘ └─────────────────────────────────────────────┘│
├─────────────────────────────────────────────────────────────┤
│  Footer: © 2026 Citcon. All rights reserved.                │
└─────────────────────────────────────────────────────────────┘
```

---

## 组件拆分

| 组件       | 路径                                 | 职责                                       |
| ---------- | ------------------------------------ | ------------------------------------------ |
| `Layout`   | `src/components/layout/Layout.tsx`   | 主布局容器，组合 Header/Sidebar/Footer     |
| `Header`   | `src/components/layout/Header.tsx`   | 顶部导航：Logo + Breadcrumb                |
| `Sidebar`  | `src/components/layout/Sidebar.tsx`  | 侧边栏容器：TreeMenu + UserMenu + 折叠按钮 |
| `TreeMenu` | `src/components/layout/TreeMenu.tsx` | 动态树形菜单：商户/层级选择                |
| `UserMenu` | `src/components/layout/UserMenu.tsx` | 静态用户菜单：功能导航 + 退出登录          |
| `Footer`   | `src/components/layout/Footer.tsx`   | 底部版权信息                               |

---

## Sidebar 详细需求

### US4: 动态树形菜单 (TreeMenu)

**作为** 已登录用户  
**我希望** 在侧边栏看到商户/层级的树形结构，可以展开查看子层级  
**以便于** 快速切换和选择要查看的商户

**验收标准:**

- [ ] 树形菜单显示在 Sidebar 上部
- [ ] 初始数据来源：登录响应 `LoginResponse.child` 作为顶层节点
- [ ] 节点显示 `value` 字段内容
- [ ] 鼠标悬停节点时，Tooltip 显示 `merchantId`
- [ ] 如果节点有 `children` 属性（数组），显示展开图标 (+)
- [ ] 点击展开图标 (+)：调用 `/api/multilayer` 接口加载子节点
  - 请求方式：POST
  - 参数：`{ parent_id: 节点id, session_id: 当前会话id }`
  - 响应：`childrens_data` 数组包含子节点列表
- [ ] 子节点如有 `children` 属性，可继续展开（递归加载）
- [ ] 点击节点名称：
  - 高亮选中该节点
  - 将节点信息存储到全局状态
  - 传递节点信息给 Dashboard 主内容页
- [ ] 加载中显示 loading 状态
- [ ] 加载失败显示 Toast 错误消息
- [ ] 展开/折叠状态刷新后保持

---

### US5: 静态用户菜单 (UserMenu)

**作为** 已登录用户  
**我希望** 在侧边栏快速访问常用功能页面  
**以便于** 高效完成日常操作

**验收标准:**

- [ ] 用户菜单显示在 Sidebar 下部（TreeMenu 下方，用分隔线分开）
- [ ] 菜单项列表：

| 菜单项                  | 图标                   | 路由/行为                             |
| ----------------------- | ---------------------- | ------------------------------------- |
| All Transactions Search | SearchOutlined         | `/alltransactions`                    |
| Account Settings        | SettingOutlined        | `/accountsettings`                    |
| Fraud Engine            | SafetyOutlined         | `/fraudengine`                        |
| Citcon Help Desk        | QuestionCircleOutlined | 新窗口打开 `http://baidu.com`         |
| Logout                  | LogoutOutlined         | 调用 `logout()` 方法，跳转到 `/login` |

- [ ] 当前路由对应的菜单项高亮显示
- [ ] 菜单项支持折叠状态（只显示图标）

---

## 状态管理

> **实现状态**: ✅ 已完成
> **相关文件**: `src/stores/uiStore.ts`, `src/stores/hierarchyStore.ts`

### UI Store (`src/stores/uiStore.ts`)

```typescript
interface UIState {
  // Sidebar
  sidebarCollapsed: boolean;
  sidebarDrawerOpen: boolean; // 移动端抽屉状态

  // TreeMenu - 选中的节点
  selectedNode: HierarchyNode | null;

  // TreeMenu - 展开的节点 keys
  expandedKeys: string[];

  // Actions
  toggleSidebar: () => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  toggleDrawer: () => void;
  setDrawerOpen: (open: boolean) => void;
  setSelectedNode: (node: HierarchyNode | null) => void;
  setExpandedKeys: (keys: string[]) => void;
}
```

**持久化配置**：

- 使用 Zustand `persist` 中间件
- 存储 key: `ui-storage`
- 持久化字段: `sidebarCollapsed`, `selectedNode`, `expandedKeys`

### Hierarchy Store (`src/stores/hierarchyStore.ts`)

```typescript
interface HierarchyState {
  // 动态加载的子节点缓存 (key: parent_id, value: children)
  childrenCache: Record<number, HierarchyNode[]>;

  // 加载状态 (当前正在加载的节点 ID 列表)
  loadingNodes: number[];

  // Actions
  fetchChildren: (parentId: number, sessionId: string, forceRefresh?: boolean) => Promise<void>;
  refreshChildren: (parentId: number, sessionId: string) => Promise<void>;
  invalidateCache: (parentId: number) => void;
  setChildren: (parentId: number, children: HierarchyNode[]) => void;
  hasChildren: (parentId: number) => boolean;
  getChildren: (parentId: number) => HierarchyNode[] | undefined;
  isLoading: (parentId: number) => boolean;
  clearCache: () => void;
}
  setChildren: (parentId: number, children: HierarchyNode[]) => void;
}
```

---

## 技术实现建议

### Ant Design 组件使用

- `Layout`, `Layout.Header`, `Layout.Sider`, `Layout.Content`, `Layout.Footer`
- `Breadcrumb`
- `Drawer` (移动端 Sidebar)
- `Button` (折叠按钮)

### AntDesign 默认主题

使用 Ant Design 5.x 默认主题，无需额外配置暗色或自定义主题。

```tsx
// src/App.tsx
import { ConfigProvider } from 'antd';

<ConfigProvider
  theme={{
    token: {
      colorPrimary: '#1890ff', // 主色调（可选，默认即此值）
      borderRadius: 6, // 圆角（可选）
    },
  }}
>
  <App />
</ConfigProvider>;
```

**主题特点：**

- 浅色背景 (`#fff` / `#f5f5f5`)
- 默认蓝色主色调 (`#1890ff`)
- 标准 Ant Design 组件样式
- Header/Sider 使用组件默认颜色或自定义深色背景 (`#001529`)

### Vite 开发服务器配置

> **配置文件**: `vite.config.ts`

```typescript
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    host: true, // 监听所有地址，包括局域网 IP
    port: 5173,
  },
});
```

**配置说明：**

| 配置项        | 值     | 说明                                                         |
| ------------- | ------ | ------------------------------------------------------------ |
| `server.host` | `true` | 监听所有网络接口，允许通过局域网 IP 访问（如 `192.168.x.x`） |
| `server.port` | `5173` | 开发服务器端口，若被占用会自动切换到下一个可用端口           |

**访问地址：**

- 本地访问: `http://localhost:5173/`
- 局域网访问: `http://192.168.x.x:5173/` （便于移动端调试）

### 响应式断点

```css
/* Tailwind 默认断点 */
sm: 640px
md: 768px
lg: 1024px
xl: 1280px
```

---

## 依赖

- **React Router**: 面包屑需要根据当前路由生成

---

## 非功能性需求

- 折叠动画时长: 200-300ms
- Sidebar 宽度过渡平滑
- 移动端抽屉有遮罩层 (backdrop)
