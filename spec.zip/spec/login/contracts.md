# Login 模块接口契约

> **实现状态**: ✅ 已完成
> **最后更新**: 2026-02-03
> **相关文件**: `src/types/auth.ts`, `src/services/api/authApi.ts`, `src/stores/authStore.ts`

## 类型定义

```typescript
// 层级节点设置
export interface HierarchyNodeSettings {
  isCollapsedOnInit?: string;
}

// 层级节点（递归结构）
export interface HierarchyNode {
  id?: number;
  value: string;
  merchantId?: string;
  hasAliDirect?: number;
  hasMultiFundings?: number;
  settings?: HierarchyNodeSettings;
  children?: HierarchyNode[];
}

// 用户信息
export interface User {
  id: number;
  email: string;
  role: string;
  sessionId: string;
}

// 登录凭证
export interface LoginCredentials {
  email: string;
  password: string;
}

// 登录响应
export interface LoginResponse {
  // 用户信息
  user_id: number;
  user_email: string;
  role: string;
  session_id: string;
  token: string | null;

  // MFA 配置
  MFA: boolean;
  config: string; // JSON 字符串，如 '{"MFA":false}'

  // 层级/商户信息
  hierarchy: number;
  hierarchyName: string;
  merchant_id: string;
  merchant_name: string;
  merchants: string[];

  // 权限
  adminPermissions: string;
  can_refund: number; // 0 或 1

  // 结算货币
  settlement_currencys: string[];

  // 时区
  timezone: string;
  timezone_short: string;

  // 层级树结构
  child: HierarchyNode[];

  // 响应状态
  code: number;
  message: string;
}
```

## Auth Store 实现

> **实现状态**: ✅ 已完成

```typescript
export interface AuthState {
  // 用户信息
  user: User | null;
  token: string | null;
  sessionId: string | null;

  // 层级/商户信息
  hierarchyId: number | null;
  hierarchyName: string | null;
  merchantId: string | null;
  merchantName: string | null;
  merchants: string[];
  hierarchyTree: HierarchyNode[];

  // 权限
  adminPermissions: string;
  canRefund: boolean;

  // MFA
  mfaEnabled: boolean;
  config: string;

  // 货币 & 时区
  settlementCurrencies: string[];
  timezone: string;
  timezoneShort: string;

  // UI 状态
  isLoading: boolean;
  error: string | null;
  currentEmail: string;

  // Actions
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => void;
  clearError: () => void;
}
```

**持久化配置**：

- 存储 key: `auth-storage`
- 持久化字段: `user`, `token`, `sessionId`, `hierarchyId`, `hierarchyName`, `merchantId`, `merchantName`, `merchants`, `hierarchyTree`, `adminPermissions`, `canRefund`, `mfaEnabled`, `config`, `settlementCurrencies`, `timezone`, `timezoneShort`, `currentEmail`

**多标签页同步**：

- 监听 `storage` 事件实现多标签页状态同步
- 当一个标签页登出时，其他标签页自动跳转到登录页

## Theme Store 实现

> **实现状态**: ✅ 已完成
> **相关文件**: `src/stores/themeStore.ts`, `src/types/theme.ts`

```typescript
export type ThemeMode = 'light' | 'dark';

export interface ThemeState {
  currentTheme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;
}
```

**持久化配置**：

- 存储 key: `theme-storage`
- 全部字段持久化

**主题配色**：

- 亮色主题主色: `#1890ff`
- 暗色主题主色: `#7c3aed`
- CSS 变量: `--primary-color`, `--primary-color-light`

## Account Settings 页面

> **实现状态**: ✅ 已完成
> **路由**: `/accountsettings`
> **相关文件**: `src/pages/AccountSettingsPage.tsx`

### 页面功能

1. **密码登录用户** (当 `AuthState.user` 有值时显示)：
   - User Email 文本框（只读，显示当前用户邮箱）
   - Password 密码框（只读）
   - Change 按钮用于修改密码

2. **MFA 用户** (当 `AuthState.mfaEnabled` 有值时显示)：
   - Phone Number 标题
   - Change 按钮用于修改电话号码

### 修改密码流程

点击 Change 按钮后弹出确认对话框，提示信息：

> "You will be taken to the login screen before the password change request can proceed."

包含两个按钮：Confirm 和 Cancel

### Nauth Login URL 接口

**POST /nauth_login_url**

请求参数：

```typescript
interface NauthLoginUrlRequest {
  /** 回调 URL */
  callback_url: string; // `${window.location.origin}/auth-callback`
  /** 用户邮箱 */
  login_hint: string; // User Email 的值
  /** 固定为 true */
  update_password: boolean;
}
```

响应结构：

```typescript
interface NauthLoginUrlResponse {
  /** 响应码，200 表示成功 */
  code: number;
  /** 成功时为重定向 URL，失败时为错误信息 */
  data: string;
}
```

**示例请求**：

```json
{
  "callback_url": "http://localhost:4200/auth-callback",
  "login_hint": "tian.yiyuan@citcon.cn",
  "update_password": true
}
```

**成功响应** (code: 200)：

```json
{
  "code": 200,
  "data": "https://id.dev01.citconpay.com/realms/merchant/protocol/openid-connect/auth?client_id=dashboard&scope=openid%20email%20profile&response_type=code&redirect_uri=http%3A%2F%2Flocalhost%3A4200%2Fauth-callback%3Fcode_challenge%3DUvUUasiBzO_DlwvWWE6q6-pqd4H-DlzLaFhov5S4ltI&code_challenge=UvUUasiBzO_DlwvWWE6q6-pqd4H-DlzLaFhov5S4ltI&code_challenge_method=S256&kc_action=UPDATE_PASSWORD&login_hint=tian.yiyuan%40citcon.cn"
}
```

**失败响应** (code: 500)：

```json
{
  "code": 500,
  "data": "error message!"
}
```

**处理逻辑**：

- 如果 `code === 200`，页面跳转到 `data` 返回的 URL
- 如果 `code !== 200`，显示 `data` 中的错误信息
