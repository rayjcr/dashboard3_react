# Tasks: Login Page

**Input**: Design documents from `/spec/login/`
**Prerequisites**: plan.md (required), spec.md (required for user stories)

**Tests**: Tests are OPTIONAL - only include them if explicitly requested in the feature specification.

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Frontend**: `src/` at repository root
- Paths follow constitution.md structure

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and environment configuration

- [x] T001 配置环境变量：更新 `.env.development`，设置 `VITE_API_URL` 为 `http://localhost:4200/api/`
- [x] T002 [P] 创建 `src/types/auth.ts`：定义 `User`, `LoginCredentials`, `AuthResponse`, `AuthState` 接口
- [x] T003 [P] 配置 `src/services/api/apiClient.ts`：确保 baseURL 使用 `import.meta.env.VITE_API_URL`
- [x] `login` API 调用接口为 `VITE_API_URL/login`。

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T004 创建 `src/services/api/authApi.ts`：实现 `login(credentials)` 和 `logout()` API 调用
- [x] T005 创建 `src/stores/authStore.ts`：
  - 读取 `spec/login/contracts.md` 中的 `login` 返回结构
  - 定义 `AuthState` 接口（user, token, isLoading, error, hierarchyId）
  - 使用 `persist` 和 `devtools` 中间件
  - 实现 `login` action：调用 `authApi.login`，更新状态，持久化 token
  - 实现 `logout` action：清除状态和 localStorage
  - 导出 `useAuthStore` hook
- [x] T006 更新 `src/stores/index.ts`：导出 `useAuthStore`

**Checkpoint**: Foundation ready - user story implementation can now begin

---

## Phase 3: User Story 1 - 登录与状态存储 (Priority: P1) 🎯 MVP

**Goal**: 用户可以通过 Ant Design 界面登录，成功后会话持久化到 Zustand 并跳转至主页

**Independent Test**: 访问 `/login`，输入正确账号密码，观察 Zustand devtools 中的 Token 变化及路由跳转

### Implementation for User Story 1

- [x] T007 [US1] 创建 `src/pages/LoginPage.tsx`：
  - 使用 Ant Design 组件：`Form`, `Input`, `Button`, `Typography`
  - 布局：居中显示，"Citcon" 标题，"Sign in to start your session" 副标题
  - 表单字段：邮箱（email 验证），密码（required 验证）
  - "Forgot Your Password" 链接
- [x] T008 [US1] 在 `LoginPage.tsx` 中集成 `useAuthStore`：
  - 处理表单提交：调用 `login` action
  - 处理加载状态（Button loading 属性）
  - 处理错误显示（`message.error`）
- [x] T009 [US1] 更新 `src/router/routes.tsx`：添加 `/login` 路由指向 `LoginPage`
- [x] T010 [US1] 在 `LoginPage.tsx` 中添加已登录用户重定向逻辑：如果已有 token，重定向到 `/`

**Checkpoint**: User Story 1 完成，可独立测试登录流程

---

## Phase 4: User Story 2 - 全局空闲自动登出 (Priority: P1)

**Goal**: 用户静止超过 20 分钟后，系统自动触发登出并跳转至登录页

**Independent Test**: 将超时时间临时改为 1 分钟，停止操作鼠标键盘，验证是否触发 logout action

### Implementation for User Story 2

- [x] T011 [US2] 创建 `src/hooks/useIdleTimeout.ts`：
  - 接受 `timeout`（毫秒）和 `onIdle`（回调）作为参数
  - 使用 `useEffect` 监听 `mousemove`, `keydown`, `click`, `scroll` 事件
  - 发生事件时重置计时器
  - 计时器到期时触发 `onIdle`
  - 组件卸载时清理监听器
- [x] T012 [US2] 更新 `src/components/layout/Layout.tsx`：
  - 引入 `useIdleTimeout` 和 `useAuthStore`
  - 仅在用户已登录状态下激活
  - 调用 `useIdleTimeout`，设置超时时间为 20 分钟（1200000 毫秒）
  - 在 `onIdle` 回调中：调用 `logout()` action
- [x] T013 [US2] 在 `authStore.ts` 的 `logout` action 中添加跳转逻辑：`window.location.href = '/login'` 或 IDP 登出 URL

**Checkpoint**: User Story 2 完成，可独立测试空闲超时登出

---

## Phase 5: User Story 3 - 路由守卫与组件保护 (Priority: P1)

**Goal**: 通过 Wrapper 组件保护敏感路由，未授权用户无法访问

**Independent Test**: 清除 LocalStorage 后直接访问 `/dashboard/users`，应被强制重定向回 `/login`

### Implementation for User Story 3

- [x] T014 [P] [US3] 创建 `src/components/auth/RequireAuth.tsx`：
  - 检查 `useAuthStore` 是否有有效 token
  - 如果未认证，`<Navigate to="/login" replace />`
  - 如果已认证，渲染 `<Outlet />`
- [x] T015 [P] [US3] 创建 `src/components/auth/PublicOnly.tsx`：
  - 检查 `useAuthStore` 是否有有效 token
  - 如果已认证，`<Navigate to="/" replace />`
  - 如果未认证，渲染 `<Outlet />`
- [x] T016 [US3] 更新 `src/router/routes.tsx`：
  - 使用 `<RequireAuth>` 包裹受保护的路由（例如 `/`, `/users`）
  - 使用 `<PublicOnly>` 包裹 `/login` 路由
- [x] T017 [US3] 创建 `src/components/auth/index.ts`：导出 `RequireAuth` 和 `PublicOnly`

**Checkpoint**: User Story 3 完成，可独立测试路由保护

---

## Phase 6: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

- [x] T018 [P] 在 `src/services/api/apiClient.ts` 中添加 Axios 响应拦截器：捕获 401 错误并触发 `logout` action
- [x] T019 [P] 添加多标签页同步：在 `authStore.ts` 中使用 `window.addEventListener('storage', ...)` 监听 token 变化
- [x] T020 代码清理和 ESLint 检查

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Stories (Phase 3-5)**: All depend on Foundational phase completion
  - User stories can proceed in priority order (P1 → P1 → P1，本项目所有故事均为 P1)
- **Polish (Phase 6)**: Depends on all desired user stories being complete

### User Story Dependencies

- **User Story 1 (登录)**: Can start after Foundational - No dependencies on other stories
- **User Story 2 (空闲登出)**: Can start after Foundational - Depends on authStore from US1
- **User Story 3 (路由守卫)**: Can start after Foundational - Depends on authStore from US1

### Parallel Opportunities

- T002, T003 can run in parallel (different files)
- T014, T015 can run in parallel (different files)
- T018, T019 can run in parallel (different concerns)

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational
3. Complete Phase 3: User Story 1
4. **STOP and VALIDATE**: Test login flow independently
5. Deploy/demo if ready

### Incremental Delivery

1. Complete Setup + Foundational → Foundation ready
2. Add User Story 1 → Test independently → Deploy/Demo (MVP!)
3. Add User Story 2 → Test idle timeout → Deploy/Demo
4. Add User Story 3 → Test route guard → Deploy/Demo
5. Add Polish → Final validation

---

## Summary

- **Total Tasks**: 20
- **Phase 1 (Setup)**: 3 tasks
- **Phase 2 (Foundational)**: 3 tasks
- **Phase 3 (US1 - 登录)**: 4 tasks
- **Phase 4 (US2 - 空闲登出)**: 3 tasks
- **Phase 5 (US3 - 路由守卫)**: 4 tasks
- **Phase 6 (Polish)**: 3 tasks
- **Parallel Opportunities**: 6 tasks marked [P]
- **MVP Scope**: Phase 1 + Phase 2 + Phase 3 (User Story 1)
