# Dispute Summary 功能规格说明

> **实现状态**: ✅ 已完成
> **最后更新**: 2026-02-03
> **相关文件**: `src/components/dashboard/DisputeSummary/`, `src/stores/disputeStore.ts`, `src/services/api/disputeApi.ts`

## 1. 概述

Dispute Summary 是用于管理和处理支付争议的功能模块。用户可以查看争议列表、筛选争议、查看争议详情，并对特定状态的争议执行操作。

## 2. 显示条件

Dispute Summary 页签在以下条件满足时显示：

1. 节点必须绑定 `merchantId`
2. `userConfig.dispute_manage === true`
3. 或者 `userConfig.daily_dispute_summary_disable === false` 并且 `hasDisputeChild === true`

## 3. 争议状态类型 (DisputeType)

| 状态值                    | 显示标签                 | 说明             |
| ------------------------- | ------------------------ | ---------------- |
| `all`                     | All                      | 全部             |
| `request_info`            | Waiting For Response     | 等待响应         |
| `under_review`            | Under Review             | 审核中           |
| `lost_waiting_for_refund` | Waiting For Refund(Lost) | 等待退款（败诉） |
| `won/lost`                | Win/Lost                 | 胜诉/败诉        |
| `close`                   | Closed                   | 已关闭           |
| `other`                   | Other                    | 其他             |

## 4. 状态显示映射

| 原始状态                  | 显示文本             | 标签颜色 |
| ------------------------- | -------------------- | -------- |
| `request_info`            | Waiting For Response | orange   |
| `under_review`            | Under Review         | blue     |
| `lost_waiting_for_refund` | Waiting For Refund   | volcano  |
| `won` / `win`             | Merchant Win         | green    |
| `lost`                    | Merchant Lost        | red      |
| `close`                   | Closed               | default  |

## 5. 筛选功能

### 5.1 筛选条件

- **日期范围**: 开始日期 - 结束日期
- **搜索关键词**: 支持搜索 Case ID、Transaction ID 等
- **争议类型**: 通过 Tab 页签切换筛选

### 5.2 交互行为

- 切换 Tab 页签立即触发搜索
- 点击 Search 按钮使用当前筛选条件搜索
- 搜索支持防抖 (300ms)

## 6. 表格列定义

| 列名                   | 字段                 | 宽度 | 对齐   | 说明                     |
| ---------------------- | -------------------- | ---- | ------ | ------------------------ |
| Operation              | -                    | 100  | center | Action 按钮（固定左侧）  |
| Dispute case ID        | caseId               | 280  | left   | 可点击查看详情，支持复制 |
| Status                 | status               | 160  | center | 显示状态标签             |
| Dispute Amount         | disputeAmount        | 130  | right  | 格式化后的金额           |
| Time Created           | timeCreated          | 180  | center | -                        |
| Last updated Time      | timeUpdated          | 180  | center | -                        |
| Payment Transaction ID | paymentTransactionId | 280  | left   | 支持复制                 |
| Payment Method         | paymentMethod        | 130  | center | -                        |
| Reason                 | reason               | 200  | left   | 争议原因                 |
| Type                   | type                 | 120  | center | 交易类型                 |
| Case Expiration Time   | caseExpirationTime   | 180  | center | -                        |

## 7. Operation 列 - Action 按钮

### 7.1 显示条件

Action 按钮的显示逻辑：

```
特殊 Vendor 列表: ['PAYPAL', 'VENMO', 'CASHAPPPAY', 'CARD', 'AFTERPAY', 'KLARNA', 'GOOGLEPAY', 'APPLEPAY']

如果 vendor 在特殊列表中:
  - 只有 status === 'request_info' 时显示 Action
否则:
  - status === 'request_info' 或 status === 'lost_waiting_for_refund' 时显示 Action
```

### 7.2 Action 弹层 (Dispute Modal)

点击 Action 按钮打开弹层：

**弹层结构：**

- **标题**: `Dispute`
- **宽度**: 700px

**内容区域：**

1. **Description 区域**
   - 显示记录的 `description` 信息
   - 支持 HTML 格式渲染（独立样式，不受项目样式影响）
   - 使用 `dangerouslySetInnerHTML` 渲染
   - 背景色: `#f5f5f5`，圆角: `4px`

2. **Note 文本框**
   - 多行文本输入框
   - 最大字符限制: 2000
   - 显示字符统计: `{num}/2000`
   - 超出 2000 字符时红色提示

3. **Provide Information 区域** (条件显示)
   - **显示条件**:
     - `status !== 'lost_waiting_for_refund'`
     - 且 `vendor` 属于 `['card', 'paze', 'afterpay', 'klarna']`
   - 包含 **Provide Information** 按钮

4. **Attachment Upload 区域** (条件显示)
   - **显示条件**: `status !== 'lost_waiting_for_refund'`
   - 显示已上传文件列表（带删除按钮）
   - **Upload Files** 按钮（样式与 Download 按钮一致）

**底部按钮：**

- `Submit` - 提交操作（暂未实现）
- `Accept and Refund` - 接受并退款（暂未实现）

**关闭行为：**

- 关闭弹层时清除所有临时数据（Note、上传文件、Provide Information 数据）
- 同时关闭子弹层（如 Provide Information 弹层）

### 7.3 Provide Information 弹层

点击 Provide Information 按钮打开子弹层：

**弹层结构：**

- **标题**: `Provide Information`
- **宽度**: 500px

**内容区域：**

1. **提示语**: `For different reasons of dispute, the type of evidence will be different.`

2. **Proof of Fulfillment 区域** (条件显示)
   - **显示条件**: `reason_code` 是 `'Unauthorized'` 或 `'merchandise or service not received'`
   - 带边框的卡片样式（背景色: `#fafafa`）
   - 包含字段：
     - `Tracking Number` - 文本输入框
     - `Carrier Name` - 文本输入框

3. **Proof of Refund 区域** (始终显示)
   - 带边框的卡片样式（背景色: `#fafafa`）
   - 包含字段：
     - `Refund ID/Reference` - 文本输入框

**底部按钮：**

- `Done` - 关闭弹层（保留数据）

**数据管理：**

- 使用对象统一管理: `{ trackNum, carrierName, refId }`
- 关闭 Provide Information 弹层时保留数据
- 关闭主弹层（Dispute Modal）时清除数据

## 8. Dispute case ID 点击 - 详情弹层

点击 Dispute case ID 打开详情弹层：

**弹层结构：**

- **标题**: `Dispute Detail`
- **宽度**: 700px

**内容区域：**

1. **基本信息** (Descriptions 组件)
   - `Dispute case ID`: 案例 ID
   - `Description`: 描述信息（支持 HTML 格式）

2. **Status Change History** (Timeline 组件)
   - 显示状态变更历史记录
   - 每条记录包含：
     - 状态标签（带颜色）
     - 更新时间
     - 来源 (note_from)
     - 备注 (note) - 支持 HTML 格式，`\n` 转换为 `<br />`
     - 证据文件列表 (evidence)

**底部按钮：**

- `Close` - 关闭弹层

## 9. 下载功能

### 9.1 CSV 下载

- 下载当前筛选条件下的所有争议数据
- 文件名格式: `DisputeSummary_YYYYMMDD_HHmmss.csv`

### 9.2 PDF 下载

- 下载当前筛选条件下的所有争议数据
- 文件名格式: `DisputeSummary_YYYYMMDD_HHmmss.pdf`
- 返回 Blob 数据

## 10. 分页

- 默认每页: 10 条
- 支持切换: 10, 20, 50, 100 条/页
- 显示总记录数和当前范围

## 11. 文件结构

```
src/
├── components/dashboard/DisputeSummary/
│   ├── index.tsx                 # 主组件（筛选、Tab、表格、下载按钮）
│   ├── DisputeSummaryTable.tsx   # 表格组件（包含详情弹层、Action弹层）
│   └── DisputeSummaryFilter.tsx  # 筛选组件
├── services/api/
│   └── disputeApi.ts             # Dispute API 服务
├── stores/
│   └── disputeStore.ts           # Dispute 状态管理
└── types/
    └── dashboard.ts              # 类型定义（Dispute 相关类型）
```
